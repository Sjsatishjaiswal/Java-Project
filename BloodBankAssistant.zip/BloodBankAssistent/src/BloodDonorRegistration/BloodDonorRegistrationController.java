package BloodDonorRegistration;
/*
import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
public class BloodDonorRegistrationController
{

    @FXML // fx:id="txtMoblie"
    private TextField txtMoblie; // Value injected by FXMLLoader

    @FXML // fx:id="txtName"
    private TextField txtName; // Value injected by FXMLLoader

    @FXML // fx:id="txtAddress"
    private TextField txtAddress; // Value injected by FXMLLoader

    @FXML // fx:id="txtCity"
    private TextField txtCity ; // Value injected by FXMLLoader

    @FXML // fx:id="txtGender"
    private ComboBox<String> txtGender; // Value injected by FXMLLoader

    @FXML // fx:id="txtBloodGroup"
    private ComboBox<String> txtBloodGroup; // Value injected by FXMLLoader

    @FXML // fx:id="txtNew"
    private RadioButton txtN; // Value injected by FXMLLoader

    @FXML // fx:id="txtRegular"
    private RadioButton txtRegular; // Value injected by FXMLLoader
    @FXML
    private ImageView txtPik;
    @FXML // fx:id="txtpath"
    private TextField txtpath; // Value injected by FXMLLoader

    Connection con;
    PreparedStatement pst;
    @FXML
    void doBrowser() {
    	FileChooser ch =new FileChooser();
    	File file=ch.showOpenDialog(null);
    	if(file!=null)
    	{
    		txtpath.setText(file.getAbsolutePath());
    		try
    		{
    			String local=file.toURL().toString();
    			Image image=new Image(local);
    			txtPik.setImage(image);
    			
    		}
    		catch(Exception ex)
    		{
    			ex.printStackTrace();
    		}
    	}
    	

    }

    
    @FXML
    void doDelete() 
    {
    	
    	String mobile=txtMoblie.getText();
    	try
    	{
    		PreparedStatement pst=con.prepareStatement("delete  from donors where mobile=?");
    		pst.setString(1, mobile);
    	int count=pst.executeUpdate();
    	System.out.println(count +"Record Deleted!");
    	
    		
    	}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}


    }

    @FXML
    void doN() {
    	txtMoblie.setText(" ");    	
   	 txtName.setText(" ");
        txtAddress.setText(" ");
        txtCity.setText(" ");
   	
   	
    }

    @FXML
    void doSave() {
    	  
    	
    	String mobile=txtMoblie.getText();
       String name = txtName.getText();
        String gender =txtGender.getSelectionModel().getSelectedItem();
       	
      String address= txtAddress.getText();
     	String city =txtCity.getText();
     	String type=txtN.getText();
     	String type1= txtRegular.getText();
     	String group=txtBloodGroup.getSelectionModel().getSelectedItem();
    	 
       
     	
   	try {
   		PreparedStatement pst=con.prepareStatement("insert into doners values(?,?,?,?,?,?,?,?,curdate())");          
   		pst.setString(1,  mobile);
   		pst.setString(2, name);
   		pst.setString(3,gender);
   		pst.setString(4,address);
   		pst.setString(5, city);
   		if(txtN.isSelected()==true)
   			pst.setString(6, type);
    	else
    		if(txtRegular.isSelected()==true)
    			pst.setString(6, type1);
    	
   		pst.setString(7,group);
   		//pst.setString(8, pik);
   	  
   	  
   		pst.executeUpdate();
   		System.out.println("Save");
   	}
   		
   	catch(Exception ex)
		{
			ex.printStackTrace();
		}
  
    }

    @FXML
    void doUpdate() {
    	String mobile=txtMoblie.getText();
        String name = txtName.getText();
        String gender =txtGender.getSelectionModel().getSelectedItem();
       	
       	String address= txtAddress.getText();
     	String city =txtCity.getText();
     	String type=txtN.getText();
     	String type1= txtRegular.getText();
     	String group=txtBloodGroup.getSelectionModel().getSelectedItem();
    	 
    	
 try {
        		PreparedStatement pst=con.prepareStatement("update  doners set name?,gender=?, address=?,city=?,group=? where mobile=?");
        		
        		pst.setString(1,name );pst.setString(1,name );
        		pst.setString(2,gender);
        		pst.setString(3, address); 
        		pst.setString(4, city);
        		pst.setString(5,group );
        		int count=pst.executeUpdate();
        		System.out.println(count+"record Update");
  
        	}
 catch (SQLException e) 
	{
		e.printStackTrace();
	}	

    	
    	
    	

    }


void initialize() {
   
 	con=DBConnection.doConnect();
 	String gender[]= {"MALE","FEMAIL"} ;                    
     txtGender.getItems().addAll(gender);      
     String group[]= {"+A","+B","+AB","+O","-O","-AB","-B","-A"} ;                    
     txtBloodGroup.getItems().addAll(group);      

 }
}



*//**
 * Sample Skeleton for 'BloodDonorRegistration.fxml' Controller Class
 */



import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;



import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class BloodDonorRegistrationController {

  

	

	@FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="txtMoblie"
    private TextField txtMoblie; // Value injected by FXMLLoader

    @FXML // fx:id="txtName"
    private TextField txtName; // Value injected by FXMLLoader

    @FXML // fx:id="txtAddress"
    private TextField txtAddress; // Value injected by FXMLLoader

    @FXML // fx:id="txtCity"
    private TextField txtCity; // Value injected by FXMLLoader

    @FXML // fx:id="txtGender"
    private ComboBox<String> txtGender; // Value injected by FXMLLoader

    @FXML // fx:id="txtBloodGroup"
    private ComboBox<String> txtBloodGroup; // Value injected by FXMLLoader

    @FXML // fx:id="txtNew"
    private RadioButton txtNew; // Value injected by FXMLLoader

    @FXML // fx:id="txtRegular"
    private RadioButton txtRegular; // Value injected by FXMLLoader

    @FXML // fx:id="txtPik"
    private ImageView txtPik; // Value injected by FXMLLoader

    @FXML // fx:id="txtpath"
    private TextField txtpath; // Value injected by FXMLLoader
    
    @FXML
    private Button btnclose;

    Connection con;
    PreparedStatement pst;

	private String type;

	private String String;
   
  
    @FXML
    void doBrowser(ActionEvent event) {
    	
    	FileChooser ch =new FileChooser();
    	File file=ch.showOpenDialog(null);
    	if(file!=null)
    	{
    		txtpath.setText(file.getAbsolutePath());
    		try
    		{
    			String local=file.toURL().toString();
    			Image image=new Image(local);
    			txtPik.setImage(image);
    			
    		}
    		catch(Exception ex)
    		{
    			ex.printStackTrace();
    		}	}
    }

    @FXML
    void doDelete(ActionEvent event) {
    	String name=txtName.getText();
    	String mobile=txtMoblie.getText();
    	try
    	{
    		PreparedStatement pst=con.prepareStatement("delete  from donors  where name=?&& mobile=?");
    		pst.setString(2, name);
    		pst.setString(1, mobile);
    	int count=pst.executeUpdate();
    	System.out.println(count +"Record Deleted!");
    	
    		
    	}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}

    }

    @FXML
    void doN(ActionEvent event) {
    	txtMoblie.setText(" ");    	
   	 txtName.setText(" ");
        txtAddress.setText(" ");
        txtCity	.setText("  ");
        txtRegular.setText("");
        txtNew.setText("");
        
    }
    
    @FXML
    void doclose(ActionEvent event) {
System.exit(0);
    }

    @FXML
    void doSave() 
    {

    	String mobile=txtMoblie.getText();
        String name = txtName.getText();
        String gender =txtGender.getSelectionModel().getSelectedItem();
       	
        String address= txtAddress.getText();
     	String city =txtCity.getText();
     	String type=txtNew.getText();
     	String type1= txtRegular.getText();
     	String group=txtBloodGroup.getSelectionModel().getSelectedItem();
    	String pik= txtpath.getText();
       
     	
   	try {
   		PreparedStatement pst=con.prepareStatement("insert into donors values(?,?,?,?,?,?,?,?,curdate())");          
   		pst.setString(1,  mobile);
   		pst.setString(2, name);
   		pst.setString(3,gender);
   		pst.setString(4,address);
   		pst.setString(5, city);
   		if(txtNew.isSelected()==true)
   			pst.setString(6, "New");
    		if(txtRegular.isSelected()==true)
    			pst.setString(6,"Regular");
    	
   		pst.setString(7,group);
   		pst.setString(8, pik);
   	  
   	  
   		pst.executeUpdate();
   		System.out.println("Save");
   		doAlert("Saved.....................");
   	}
   		
   	catch(Exception ex)
		{
			ex.printStackTrace();
		}
  
    }
  /*  @FXML
    void doEdit(ActionEvent event) {
    	try {
    		PreparedStatement pst=con.prepareStatement("update  donors set name=?,gender=?, address=?,city=?,type=?,group=? where mobile=?");
    		
    		pst.setString(1, name);
    		pst.setString(2, gender);
    		
    		pst.setString(3,address);
    		pst.setString(4, city);
    		pst.setString(5,group);
    		
    		pst.setString(5, mobile);
    		int count=pst.executeUpdate();
    		System.out.println(count+"record Update");
    		doAl(".....UPDATED......");
    	}
    		
    	catch(SQLException ex)
		{
			ex.printStackTrace();
		}
   
    	catch (SQLException e) 
		{
			e.printStackTrace();
		}	


    }*/

    @FXML
    void doEdit(ActionEvent event) {
    	String type = null;
    	        String name =txtName.getText();
	         	String mob=txtMoblie.getText();
	         	String gen=txtGender.getPromptText();
	      	    String address=txtAddress.getText();
	      	    String city =txtCity.getText();
	      	  String group= txtBloodGroup.getPromptText();
	      	  String pik= txtpath.getText();
	      	String type1=txtNew.getText();
	     	String type2= txtRegular.getText();
	      	  
	      	
		        String gender =txtGender.getSelectionModel().getSelectedItem();	
			
	 try {
	        		PreparedStatement pst=con.prepareStatement("update  donors set name=?,gender=?, address=?,city=?,type=mam=?,group=?,pik=? where mobile=?");
	        		
	        		pst.setString(1, name);
	        		
	        		pst.setString(2,gender);
	        		pst.setString(3,address); 
	        		pst.setString(4, city);
	        		
	        		if(txtNew.isSelected()==true)
	           			pst.setString(5, "New");
	            		if(txtRegular.isSelected()==true)
	            			pst.setString(5,"Regular");
	        		pst.setString(6, group);
	       	   		pst.setString(7, pik);
	        	   //	pst.setString(8, mobile);
		        	 	
	        		int count=pst.executeUpdate();
	        		System.out.println(count+"record Update");
	        		doAl(".....UPDATED......");
	        		
	        	}
	 catch (SQLException e) 
		{
			e.printStackTrace();
		}	

    }

    
    void doAlert(String msg)
    {
 	   Alert alert = new Alert(AlertType.CONFIRMATION);
 	   alert.setTitle("my AlertBox");
 	   alert.setHeaderText("information");
 	   alert.setContentText(msg);
 	   alert.showAndWait();
 	   
    }
    void doAl(String msg)
    {
 	   Alert alert = new Alert(AlertType.INFORMATION);
 	   alert.setTitle("my AlertBox");
 	   alert.setHeaderText("information");
 	   alert.setContentText(msg);
 	   alert.showAndWait();
 	   
    }
    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
       
        
        con=BDRDBConnection.doConnect();
     	String gender[]= {"MALE","FEMALE"} ;                    
         txtGender.getItems().addAll(gender);      
         String group[]= {"A+","B+","AB+","O+","O-","AB-","B-","A-"} ;                    
         txtBloodGroup.getItems().addAll(group);      

    }
}
