

package DonorsConsole;
	import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.ResourceBundle;

import BloodDonorRegistration.BDRDBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

	public class  DonorsController{

	    @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private TableView<DonorsBean> txtTable;

	    
	    @FXML
	    private ComboBox<String> txtGroup;

	    @FXML
	    private ComboBox<String> txtCity;

	    @FXML
	    void doExp(ActionEvent event) {
	    	
	    }
	    Connection con;
	    PreparedStatement pst;
	    @FXML
	    void doShow() throws Exception
	    {
	    	fillColumns();

	    	 try {
	 			String City=txtCity.getSelectionModel().getSelectedItem();
	 	
	    		 PreparedStatement	pst=Con.prepareStatement("select * from donors where city=? ");
	    		pst.setString(1,City );
	    		
	    		 fetchAllRecords(pst);
	        	 
	    	    txtTable.setItems(list);
			} 
             catch(SQLException e)
	    	{
  
            	 e.printStackTrace();
	    	}
	    }
	    
	    

	    

	    @FXML
	    void doFetch(ActionEvent event) throws Exception {
	    	fillColumns();
	    	try {
	 			String vog=txtGroup.getSelectionModel().getSelectedItem();//take the box blood group
	 			System.out.println(vog);
	    		 PreparedStatement	pst=Con.prepareStatement("select * from donors where 'group=?'");
	    		 pst.setString(1, vog);
	    		 fetchAllRecords(pst);
	    	    txtTable.setItems(list);
	    		
	    	/*ResultSet table = pst.executeQuery();
	        	 	 
	    		while(table.next())
        		{
        			String mobile=table.getString("mobile");//col. name acc. to table
        			String name=table.getString("name");
        			String gender=table.getString("gender");
        			String address=table.getString("address");
        			String city=table.getString("city");
        			String type=table.getString("type");
        			String group=table.getString("group");
        			String pik=table.getString("pik");
        			Date Date=table.getDate("dor");
        			System.out.println(mobile+"  "+name+"  "+gender+"   "+address+" "+city+"  "+type+" "+group+" "+pik+" "+Date);
        			DonorsBean sb=new DonorsBean(name,mobile,city,address,gender,type,group,pik,Date);
        			list.add(sb);
        			
        		}
        		*/
	    	}
	    	
             catch(SQLException e)
	    	{
 
            	 e.printStackTrace();
	    	}
	    }
	    
	    ObservableList<DonorsBean> list;
	    Connection Con;
	    
	    
	   
	    void fetchAllRecords(PreparedStatement pst)
	    {
	    	 fillColumns();
	    	list=FXCollections.observableArrayList();
	    	try{
	        
	        	ResultSet table= pst.executeQuery();
	        		
	    
	        		while(table.next())
	        		{
	        			String mobile=table.getString("mobile");//col. name acc. to table
	        			String name=table.getString("name");
	        			String gender=table.getString("gender");
	        			String address=table.getString("address");
	        			String city=table.getString("city");
	        			String type=table.getString("type");
	        			String group=table.getString("group");
	        			String pik=table.getString("pik");
	        			
	        			Date Date=table.getDate("dor");
	        			System.out.println(mobile+"  "+name+"  "+gender+"   "+address+" "+city+"  "+type+" "+group+" "+pik+" "+Date);
	        			DonorsBean sb=new DonorsBean(name,mobile,city,address,gender,type,group,pik,Date);
	        			list.add(sb);
	        			
	        		}
	        	}
	        	catch(Exception ex)
	        	{
	        		ex.printStackTrace();
	        	}
	    	
	    }
	  
	    void fillColumns()
	    {
	    	TableColumn<DonorsBean, String> mobile=new TableColumn<DonorsBean, String>("Mobile number");//Dikhava Title
	     	mobile.setCellValueFactory(new PropertyValueFactory<>("mobile"));//bean field name, no link with table col name

	     	TableColumn<DonorsBean, String> name=new TableColumn<DonorsBean, String>("Donor Blood Name");//Dikhava Title
	     	name.setCellValueFactory(new PropertyValueFactory<>("name"));//bean field name, no link with table col name
	     	
	     	TableColumn<DonorsBean, String> gender=new TableColumn<DonorsBean, String>("gender");//Dikhava Title
	     	gender.setCellValueFactory(new PropertyValueFactory<>("gender"));//bean field name, no link with table col name
	     	TableColumn<DonorsBean, String> address=new TableColumn<DonorsBean, String>("Address");//Dikhava Title
	     	address.setCellValueFactory(new PropertyValueFactory<>("address"));//bean field name, no link with table col name

	     	TableColumn<DonorsBean, String> city=new TableColumn<DonorsBean, String>("Donor Blood City");//Dikhava Title
	     	city.setCellValueFactory(new PropertyValueFactory<>("city"));//bean field name, no link with table col name
	     	
	     	TableColumn<DonorsBean, String> type=new TableColumn<DonorsBean, String>("Type");//Dikhava Title
	     	type.setCellValueFactory(new PropertyValueFactory<>("type"));//bean field name, no link with table col name
	     	TableColumn<DonorsBean, String> group=new TableColumn<DonorsBean, String>("Donor Blood Group");//Dikhava Title
	     	group.setCellValueFactory(new PropertyValueFactory<>("group"));//bean field name, no link with table col name
	     	
	     	TableColumn<DonorsBean, String> pik=new TableColumn<DonorsBean, String>("Photo");//Dikhava Title
	     	pik.setCellValueFactory(new PropertyValueFactory<>("pik"));//bean field name, no link with table col name
	     	


	     	TableColumn<DonorsBean, String> dor=new TableColumn<DonorsBean, String>("Date of Registation");//Dikhava Title
	     	dor.setCellValueFactory(new PropertyValueFactory<>("date"));//bean field name, no link with table col name
	     	
	     	txtTable.getColumns().clear();
	     	txtTable.getColumns().addAll(mobile,name,gender,address,city,type,group,pik,dor );
	    }
void showcity() throws Exception 
{  
	
ObservableList<String>arr= FXCollections.observableArrayList();
pst=Con.prepareStatement("select city from donors");
ResultSet tbl=pst.executeQuery();

while (tbl.next())
     {
String Cty=tbl.getString("city");

               arr.add(Cty);
      }

txtCity.setItems(arr);
//showGroup();

}
void Group() throws Exception 
{  
	ArrayList<String> al = new ArrayList<String>(Arrays.asList());
	
	
pst=Con.prepareStatement("select  *  from donors");
ResultSet tbl=pst.executeQuery();

while (tbl.next())
     {
String G=tbl.getString("group");

al.add(G);

      }
txtGroup.getItems().addAll(al);




}

  
	    @FXML
	    void initialize() throws  Exception
	    {
	        
	        Con=BDRDBConnection.doConnect();
	    	// fillColumns();
//String group[]= {"A+","B+","AB+","O+","O-","AB-","B-","A-"} ;           
	//txtGroup.getItems().addAll(group); 
	   //  showcity() ;
 	     showcity();
 	     Group();
	    
	    }
	}



