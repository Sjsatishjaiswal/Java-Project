package DonorsConsole;

import java.util.Date;

public class DonorsBean   
{

	String name,mobile,city,address,gender,type,group,pik;
	Date date;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getPik() {
		return pik;
	}
	public void setPik(String pik) {
		this.pik = pik;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public DonorsBean(String name, String mobile, String city, String address, String gender, String type, String group,
			String pik, Date date) {
		super();
		this.name = name;
		this.mobile = mobile;
		this.city = city;
		this.address = address;
		this.gender = gender;
		this.type = type;
		this.group = group;
		this.pik = pik;
		this.date = date;
	}
	public DonorsBean() {}
	
}
