package DonationHistory;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import BloodDonorRegistration.BDRDBConnection;
import DonorsConsole.DonorsBean;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class DonationController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;


    @FXML
    private DatePicker txtDateFrom;

    @FXML
    private DatePicker txtDateTo;


    @FXML
    private TextField txtmob;

    @FXML
    private TableView<DonationBean> txtTable;
  
    Connection con;
    PreparedStatement pst;
    ObservableList<DonationBean> list;


    @FXML
    void doShow(ActionEvent event) throws SQLException {
    try {
    	LocalDate date=txtDateFrom.getValue();
    	java.sql.Date AF=java.sql.Date.valueOf(date);
    	//LocalDate dateto=txtDateTo.getValue();
    	//java.sql.Date Ato=java.sql.Date.valueOf(dateto);
    	  PreparedStatement pst=con.prepareStatement("select * from donors where dor=? ") ; 	
    	    	pst.setDate(1, AF);
    	    	//pst.setDate(2,Ato);
    	    	ResultSet table = pst.executeQuery();
    	    	while(table.next())
    	    	{
    	    		String mob = table.getString("mobile");
    	 	       	String name = table.getString("name");
    	 	       		String gen = table.getString("gender");
    	 	       		String address = table.getString("address");
    	 	       		String city= table.getString("city");
    	 	       		String type= table.getString("type");
    	 	       		String group = table.getString("group");
    	 	       		String pik = table.getString("pik");
    	 	       		String cdate = table.getString("dor");
    	 	       		DonationBean bean = new DonationBean(mob,name,gen,address,city,type,group,pik,cdate);
    	 	       		
    	 	       		
    	 	    			list.add(bean);
    	 	    			txtTable.setItems(list);
    	    	}
    	    	
    }
    	    	  catch(SQLException e)
    	      	{

    	          	 e.printStackTrace();
    	      	}  	
    	    }
    
    	
    


    @FXML
    void doShowAll(ActionEvent event) throws SQLException
    {
    	
    	try{
 	        
	    		
 	       	list=FXCollections.observableArrayList();
 	        
 	           pst=con.prepareStatement("select * from donors") ; 	
 	       	ResultSet table = pst.executeQuery();
 	       	while(table.next())
 	       	{
 	       		
 	       		String mob = table.getString("mobile");
 	       	String name = table.getString("name");
 	       		String gen = table.getString("gender");
 	       		String address = table.getString("address");
 	       		String city= table.getString("city");
 	       		String type= table.getString("type");
 	       		String group = table.getString("group");
 	       		String pik = table.getString("pik");
 	       		String cdate = table.getString("dor");
 	       		DonationBean bean = new DonationBean(mob,name,gen,address,city,type,group,pik,cdate);
 	       		
 	       		
 	    			list.add(bean);
 	    			txtTable.setItems(list);
 	    			
 	       
 	       	}
 	      
 	        	}
 	        	catch(Exception ex)
 	        	{
 	        		ex.printStackTrace();
 	        	}
    }
   
    
    
   


    
    @FXML
    void txtSearchMob(ActionEvent event) {
    	
    	try {
 			String G=txtmob.getText();
    		 PreparedStatement	pst=con.prepareStatement("select * from donors where mobile=?");
    		 pst.setString(1,G );
    			ResultSet table = pst.executeQuery();
     	       	while(table.next())
     	       	{
     	       		
     	       		String mob = table.getString("mobile");
     	       	String name = table.getString("name");
     	       		String gen = table.getString("gender");
     	       		String address = table.getString("address");
     	       		String city= table.getString("city");
     	       		String type= table.getString("type");
     	       		String group = table.getString("group");
     	       		String pik = table.getString("pik");
     	       		String cdate = table.getString("dor");
     	       		DonationBean bean = new DonationBean(mob,name,gen,address,city,type,group,pik,cdate);
     	       		
     	       		
     	    			list.add(bean);
     	    			txtTable.setItems(list);
     	    			
     	    			
     	       
     	       	}
    		 
        	 
    	   // txtTable.setStyle(list);
    	   
		} 
         catch(SQLException e)
    	{

        	 e.printStackTrace();
    	}
    } 
 	    Connection Con;
    	 
    	 void fillColumns()
 	    {
    			
  	       	list=FXCollections.observableArrayList();
    			
 	    	TableColumn<DonationBean, String> mobile=new TableColumn<DonationBean, String>("Mobile number");//Dikhava Title
 	     	mobile.setCellValueFactory(new PropertyValueFactory<>("mobile"));//bean field name, no link with table col name

 	     	TableColumn<DonationBean, String> name=new TableColumn<DonationBean, String>("Donor Blood Name");//Dikhava Title
 	     	name.setCellValueFactory(new PropertyValueFactory<>("name"));//bean field name, no link with table col name
 	     	
 	     	TableColumn<DonationBean, String> gender=new TableColumn<DonationBean, String>("gender");//Dikhava Title
 	     	gender.setCellValueFactory(new PropertyValueFactory<>("Gender"));//bean field name, no link with table col name
 	     	TableColumn<DonationBean, String> address=new TableColumn<DonationBean, String>("Address");//Dikhava Title
 	     	address.setCellValueFactory(new PropertyValueFactory<>("address"));//bean field name, no link with table col name

 	     	TableColumn<DonationBean, String> city=new TableColumn<DonationBean, String>("Donor Blood City");//Dikhava Title
 	     	city.setCellValueFactory(new PropertyValueFactory<>("city"));//bean field name, no link with table col name
 	     	
 	     	TableColumn<DonationBean, String> type=new TableColumn<DonationBean, String>("Type");//Dikhava Title
 	     	type.setCellValueFactory(new PropertyValueFactory<>("type"));//bean field name, no link with table col name
 	     	TableColumn<DonationBean, String> group=new TableColumn<DonationBean, String>("Donor Blood Group");//Dikhava Title
 	     	group.setCellValueFactory(new PropertyValueFactory<>("group"));//bean field name, no link with table col name
 	     	
 	     	TableColumn<DonationBean, String> pik=new TableColumn<DonationBean, String>("Photo");//Dikhava Title
 	     	pik.setCellValueFactory(new PropertyValueFactory<>("pik"));//bean field name, no link with table col name
 	     	


 	     	TableColumn<DonationBean, String> dor=new TableColumn<DonationBean, String>("Date of Registation");//Dikhava Title
 	     	dor.setCellValueFactory(new PropertyValueFactory<>("dor"));//bean field name, no link with table col name
 	     	
 	     	txtTable.getColumns().clear();
 	     txtTable.getColumns().addAll(mobile,name,gender,address,city,type,group,pik,dor);
 	    
 	    }
    @FXML
    void initialize() {
        
    	
    	 con=BDRDBConnection.doConnect();
    	 fillColumns();
    }
}
