package DonationHistory;

public class DonationBean {
	String mobile;
	
	String name;
	String gender;
	String address;
	String city;
	String type;
	String group;
	String pik;
	String dor;
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getPik() {
		return pik;
	}
	public void setPik(String pik) {
		this.pik = pik;
	}
	public String getDor() {
		return dor;
	}
	public void setDor(String dor) {
		this.dor = dor;
	}
	public DonationBean(String mobile, String name, String gender, String address, String city, String type,
			String group, String pik, String dor) {
		super();
		this.mobile = mobile;
		this.name = name;
		this.gender = gender;
		this.address = address;
		this.city = city;
		this.type = type;
		this.group = group;
		this.pik = pik;
		this.dor = dor;
	}
	
public DonationBean() {}
}
