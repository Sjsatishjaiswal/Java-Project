package BloodDonationEntry;

	import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URI;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
	import javafx.event.ActionEvent;
	import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.util.Date;
import java.text.SimpleDateFormat;
	public class  BloodDonationEntryController {

	    @FXML
	    private ResourceBundle resources;

	    @FXML
	    private URL location;

	    @FXML
	    private TextField txtMobile;

	    @FXML
	    private TextField txtName;

	    @FXML
	    private ImageView txtImage;

	    @FXML
	    private TextField txtDOD;

	    @FXML
	    private ComboBox<String> combomob;
	    
	    @FXML
	    private DatePicker txtDate;


	    @FXML
	    private TextField txtGroup;
	    Connection con;
	    PreparedStatement pst;

		


	    @FXML
	    void doFetch(ActionEvent event) {
	    	
try {
	    	
	    		String mob = combomob.getSelectionModel().getSelectedItem();
				pst=con.prepareStatement("select * from donors where mobile=?");
			
	    		pst.setString(1, mob);
				ResultSet table = pst.executeQuery();
				boolean jasus=false;
				while(table.next())
				{
					
				jasus=true;
					String name= table.getString("name");
					txtName.setText(name);
					txtGroup.setText(table.getString("group"));
					java.sql.Date date=table.getDate("dor");
					 String d=String.valueOf(date);
					 txtDate.setPromptText(d);
					//System.out.println(table.getString("mobile"));
					 String Image= table.getString("pik");
					 
				
		    		
		    			try {
							txtImage.setImage(new Image(new FileInputStream(Image)));
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	    	

	    }

	    private Object toURL() {
			// TODO Auto-generated method stub
			return null;
		}

		@FXML
	    void doNew(ActionEvent event) {
	    	   	
	      	 txtName.setText(" ");
	      	txtDate.setPromptText("");
	      	txtGroup  .setText("  ");
	    txtImage.setAccessibleHelp("");
	    combomob.getSelectionModel().clearSelection();
	    }
	   
	    @FXML
	    void doSubmit(ActionEvent event) throws Exception
	    {
	    	
	    	String mobile= combomob.getSelectionModel().getSelectedItem();
	    	System.out.println(mobile);
	        String name = txtName.getText();
	        
	       	String group=txtGroup.getText();
	       	String date = String.valueOf(txtDate.getPromptText());
	       	java.sql.Date D =java.sql.Date.valueOf(date);
	       	
	      // 	String pik= txdate tImage.get();
	   
	   //  String pik= txtImage.getText();
	       
	     	
	   	try {
	   		PreparedStatement pst=con.prepareStatement("insert into donationhistory values(?,?,?,?,curdate())");          
	   		pst.setString(1,  mobile);
	   		pst.setString(2, name);
	   		pst.setString(3,group);
	   		pst.setDate(4, D);
	   	  
	   		pst.executeUpdate();
	   		System.out.println("Submit");
	   		doAlert("Saved.....................");
	   	}
	   		
	   	catch(Exception ex)
			{
				ex.printStackTrace();
			}
	  
	    }
	    
	  void mobfetch()
	  {
		  ArrayList<String> all = new ArrayList<String>();
	    	try {
	    	
	    		
				pst=con.prepareStatement("select mobile from donors");
			
	    		
				ResultSet table = pst.executeQuery();
				boolean jasus=false;
				while(table.next())
				{
					
				jasus=true;
					String mob = table.getString("mobile");
					System.out.println(table.getString("mobile"));
					all.add(mob);
				}
				
				combomob.getItems().addAll(all);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	  }
	  
       void doAlert(String msg)
       {
    	   Alert alert = new Alert(AlertType.CONFIRMATION);
    	   alert.setTitle("my AlertBox");
    	   alert.setHeaderText("information");
    	   alert.setContentText(msg);
    	   alert.showAndWait();
    	   
       }
	    @FXML
	    void initialize() {
	    	con = EntryDBConnection.doConnect();
	    	mobfetch();
	 
	    }
	}



