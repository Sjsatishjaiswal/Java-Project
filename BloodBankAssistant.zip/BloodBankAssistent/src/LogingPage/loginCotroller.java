package LogingPage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import sms.SST_SMS;

public class loginCotroller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtPass;

    @FXML
    void doForgot(ActionEvent event) {
    	
     String msg =  SST_SMS.bceSunSoftSend("9205324610", "your password is pwd");
     doAlert(msg);
    }

    @FXML
    void doGoToDashboard(ActionEvent event) {
     String uid = txtId.getText();
     String pwd = txtPass.getText();
     if(uid.equals("Satish")&& pwd.equals("123"))
     {
    	 try {
 			Parent root =FXMLLoader.load(getClass().getClassLoader().getResource("Dashboard/Dashboard.fxml"));
 			Scene scene = new Scene(root);
 			Stage stage = new Stage();
 			stage.setScene(scene);
 			stage.show();
 			
 		} catch (IOException e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
     	
     }
     else
     {
    	 doAlert("                   ..........Wrong Enter!!..\n                ....Please  Enter Correct...............");
      	   
     }
    }
    void doAlert(String msg)
    {
 	   Alert alert = new Alert(AlertType.CONFIRMATION);
 	   alert.setTitle("my AlertBox");
 	   alert.setHeaderText("information");
 	   alert.setContentText(msg);
 	   alert.showAndWait();
 	   
    }
    @FXML
    void initialize() {
       
    }
}
